#include <stdio.h> // Required for standard input/output functions (printf, scanf, fprintf, getchar, EOF)
#include <stdlib.h> // Required for exit() (though not strictly used here, return 1 from main is sufficient)

// Main function - the entry point of the program.
// It orchestrates the entire process of taking input and printing the table.
int main() {
    // Declare an integer variable to store the number entered by the user.
    int number;
    // Declare a loop counter variable.
    int i;
    // Define the maximum multiplier for the table.
    // Using 'const' makes this a compile-time constant, improving readability and maintainability.
    // The table will be generated from 1 up to this value.
    const int MAX_MULTIPLIER = 10;

    // --- Program Start and User Input Phase ---
    printf("--- Multiplication Table Generator ---\n");
    printf("This program will generate a multiplication table for an integer you provide.\n");
    printf("Please enter an integer (e.g., 5): ");

    // Read the integer input from the user.
    // scanf returns the number of items successfully read.
    // We expect 1 item (an integer) to be read successfully.
    if (scanf("%d", &number) != 1) {
        // --- Error Handling for Invalid Input ---
        // If scanf did not read an integer successfully, it means invalid input was provided (e.g., text).
        fprintf(stderr, "Error: Invalid input. Please enter a valid integer.\n");

        // Clear the input buffer to prevent issues with potential subsequent reads
        // in a more complex application, or to ensure a clean exit.
        // This loop reads and discards characters until a newline or End-Of-File (EOF) is encountered.
        int c;
        while ((c = getchar()) != '\n' && c != EOF);

        // Return a non-zero value to indicate an error during program execution.
        return 1; // Indicate failure
    }

    // --- Input Buffer Cleaning (after successful read) ---
    // Consume any remaining characters on the line after the integer input, including the newline.
    // This is good practice to ensure the input buffer is clean for any future reads (if the program
    // were more complex), and to handle cases where the user types "5abc" (scanf reads 5, "abc\n" remains).
    int c;
    while ((c = getchar()) != '\n' && c != EOF);

    // --- Logging Input Confirmation ---
    printf("\nSuccessfully received input: %d\n", number);
    printf("------------------------------------\n");
    printf("Generating multiplication table for: %d\n", number);
    printf("------------------------------------\n");

    // --- Table Generation Phase ---
    // Use a for loop to iterate from 1 up to MAX_MULTIPLIER.
    // In each iteration, we calculate and print the product.
    for (i = 1; i <= MAX_MULTIPLIER; i++) {
        // Calculate the product of the input number and the current multiplier.
        // We cast 'number' to 'long long' before multiplication to prevent potential
        // integer overflow if 'number' or 'i' are large, ensuring the product fits
        // into 'long long' even if it exceeds the capacity of 'int'.
        long long product = (long long)number * i;

        // Print the multiplication expression and its result.
        // The format specifier %lld is used for printing 'long long' integers.
        printf("%d x %d = %lld\n", number, i, product);
    }

    // --- Program End Logging ---
    printf("------------------------------------\n");
    printf("Multiplication table generation complete.\n");
    printf("Thank you for using the program!\n");

    // Return 0 to indicate successful program execution.
    return 0; // Indicate success
}
