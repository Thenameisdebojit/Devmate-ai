#include<stdio.h>
#include<stdlib.h>
void create(int a[10], int n) //defination of create Function
{
    int i;
    printf("\nEnter n:\n");
    scanf("%d", &n);
    printf("\n Enter Data Into Array: \n");
    for(i=0;i<n;i++)
        scanf("%d", &a[i]);
}
void traverse(int a[], int lb, int ub)
{
    int i=lb;
    printf("\n content of the array: \n");
    while(i<=ub)
    {
        printf("%d \t", a[i]);
        i++;
    }
}
int main()
{
    int a[10],n;
    create(a,n); //call to create Function
    traverse(a,0,n-1); //call to traverse Function����
}
