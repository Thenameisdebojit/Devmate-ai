#include<stdio.h>
#include<stdlib.h>
#define MAX 10

// struct stack{
//     int a[MAX];
//     int top;
// };
// typedef struct stack STACK;
// int isempty(STACK*s){
//     if(s->top==-1){
//         return 1;
//     }
//     return 0;
// }
// int isfull(STACK*s){
//     if(s->top==MAX-1){
//         return 1;
        
//     }
//     return 0;
// }
// void push(STACK*s,int item){
//     if(isfull(s)){
//         printf("stack is full\n");
//         return;

//     }
//     s->top++;
//     s->a[s->top]=item;
// }
// void pop(STACK*s){
//     if(isempty(s)){
//         printf("UNDERFLOW ERROR\n");
//         return;
//     }
//     int item=s->a[s->top];
//     s->top--;
//     printf("popped item is %d\n",item);
// }
// void peep(STACK*s){
//     if(isempty(s)){
//         printf("stack is empty");
//     }
//     else{
//         for(int i=s->top;i>=0;i--){
//             printf("%d",s->a[i]);
//             printf("\t");
//         }
//         printf("\n");
//     }
// }
// int main(){
//     int item,option;
//     STACK s;
//     s.top=-1;
//     do{
//         printf("\nMENU\n1->push\n2>pop\n3->peep\n4->EXIT\nenter your option\n");
//         scanf("%d",&option);
//         switch(option){
//             case 1: printf("enter item to be insert");
//                     scanf("%d",&item);
//                     push(&s,item);
//                     break;
//             case 2: pop(&s);
//                     break;
//             case 3: peep(&s);
//                     break;
//             case 4: exit(0);
//             default: printf("invalid option");
//         }
//     }while(option<5);
//     return 0;
// }


// QUEUE IMPLEMENTATION USING ARRAY
// struct queue{
//     int a[MAX];
//     int r;
//     int f;
// };
// typedef struct queue QUEUE;
// int isempty(QUEUE*q){
//     if(q->f==-1){
//         return 1;
//     }
//     return 0;
// }
// int isfull(QUEUE*q){
//     if(q->r==MAX-1){
//         return 1;
//     }
//     return 0;
// }
// void display(QUEUE*q)
// {
//     if(isempty(q)){
//         printf("QUEUE is empty");
//     }
//     else{
//         for(int i=q->f;i<=q->r;i++){
//             printf("%d ",q->a[i]);
//             printf("\t");
//         }
//         printf("\n");
//     }

// }
// void enqueue(QUEUE*q,int item){
//     if(isfull(q)){
//         printf("QUEUE OVERFLOW ERROR");
//         return;
//     }
//     else if(q->f==-1 && q->r==-1){
//         q->f=0;
//         q->r=0;
//         q->a[q->r]=item;
//     }
//     else{
//         q->r++;
//         q->a[q->r]=item;
//     }
//     display(q);
// }
// void dequeue(QUEUE*q){
//     if(isempty(q)){
//         printf("QUEUE UNDERFLOW ERROR");
//         return;
//     }
//     int item = q->a[q->f];
//     if(q->f == q->r){
//         q->f = -1;
//         q->r = -1;
//     }
//     else{
//         q->f++;
//         printf("deleted item is: %d\n", item);
//     }
//     display(q);
// }
// int main(){
//     QUEUE q;
//     int item,option;
//     q.f=-1;
//     q.r=-1;
//     do{
//         printf("\nMENU\n1->enque\n2->dequeue\n3->display\nenter your option\n");
//         scanf("%d",&option);
//         switch(option){
//             case 1:printf(" enter item to insert");
//                    scanf("%d",&item);
//                    enqueue(&q,item);
//                    break;
//             case 2:dequeue(&q);
//                    break;
//             case 3:display(&q);
//                    break;
//             case 4:exit(0);
//             default:printf("invalid option");
//         }
//     }while(option<5);
//     return 0;
// }



//CIRCULAR QUEUE IMPLEMENTATION USING ARRAY
// struct cqueue{
//     int a[MAX];
//     int f;
//     int r;
// };
// typedef struct cqueue CQUEUE;
// int isempty(CQUEUE*cq){
//     if(cq->f==-1){
//         return 1;
//     }
//     return 0;
// }
// int isfull(CQUEUE*cq){
//     if(cq->f==0 && cq->r==MAX-1 || cq->f==cq->r+1){
//         return 1;
//     }
//     return 0;
// }
// void display(CQUEUE*cq){
//     if(isempty(cq)){
//         printf("CIRCULAR QUEUE IS EMPTY");
//     }
//     else{
//         if(cq->f<=cq->r){
//             for(int i=cq->f;i<=cq->r;i++){
//                 printf("%d ",cq->a[i]);
//             }
//             printf("\n");

//         }
//         else{
//             for(int i=0;i<=cq->r;i++){
//                 printf("%d ",cq->a[i]);
//             }
//             for(int i=cq->f;i<MAX;i++){
//                 printf("%d ",cq->a[i]);
//             }
//             printf("\n");
//         }
//     }
// }
// void enqueue(CQUEUE*cq,int item){
//     if(isfull(cq)){
//         printf("CIRCULAR QUEUE OVERFLOW ERROR!");
//         return;
//     }
//     else if(cq->f==-1 && cq->r==-1){
//         cq->f=0;
//         cq->r=0;
//         cq->a[cq->r]=item;
//     }
//     else if(cq->r==MAX-1){
//         cq->r=0;
//         cq->a[cq->r]=item;
//     }
//     else{
//         cq->r++;
//         cq->a[cq->r]=item;
//     }
//     display(cq);
// }
// void dequeue(CQUEUE*cq){
//     if(isempty(cq)){
//         printf("CIRCULAR QUEUE UNDERFLOW ERROR!");
//         return;
//     }
//     int item=cq->a[cq->f];
//     if(cq->f==cq->r){
//         cq->f=-1;
//         cq->r=-1;
//         printf("deleted item is: %d\n", item);
//     }
//     else if(cq->f==MAX-1){
//         cq->f=0;
//         printf("deleted item is: %d\n", item);
//     }
//     else{
//         cq->f++;
//         printf("deleted item is: %d\n", item);
//     }
//     display(cq);
// }
// int main(){
//     int item,op;
//     CQUEUE cq;
//     cq.f=-1;
//     cq.r=-1;
//     do{
//         printf("\nPRESS\n1->enqueue\n2->dequeue\n3->display\n4->EXIT\n enter your option\n");
//         scanf("%d",&op);
//         switch(op){
//             case 1: printf("enter item to be insert");
//                     scanf("%d",&item);
//                     enqueue(&cq,item);
//                     break;
//             case 2: dequeue(&cq);
//                     break;
//             case 3: display(&cq);
//                     break;
//             case 4: exit(0);
//             default: printf("invalid option");
//         }
//     }while(op<5);
// }




// ARRAY OPERATION
void create(int arr[100],int*n){
    printf("enter no of elements to be stored");
    scanf("%d",&n);
    printf("enter elements to be stored");
    for(int i=0;i<*n;i++){
        scanf("%d",&arr[i]);
    }
}
void display(int arr[100],int n){
    printf("elements are:");
    for(int i=0;i<=n-1;i++){
        printf("%d ",arr[i]);
    }
}

void insert(int arr[100],int*n,int pos,int val){
    for(int i=*n-1;i>=pos-1;i--){
        arr[i+1]=arr[i];
    }
    arr[pos]=val;
    (*n)++;

}
void delete(int arr[100],int*n,int pos){
    int val=arr[pos-1];
    for(int i=pos-1;i<=*n-1;i++){
        arr[i]=arr[i+1];
    }
    (*n)--;
   printf("deleted item is: %d\n", val);
   display(arr, *n);
}
int main(){
    int arr[100],n,pos,val,option;
    create(arr,&n);
    do{
        printf("\nenter your option\n1->insert\n2->delete\n3->display\n4->Exit\n");
        scanf("%d",&option);
        switch(option){
            case 1: printf("enter pos and element ");
                    scanf("%d %d",&pos,&val);
                    insert(arr,&n,pos,val);
            case 2: printf("enter pos to delete ");
                    scanf("%d",&pos);
                    delete(arr,&n,pos);
                    break;
            case 3: display(arr,n);
                    break;
            case 4: exit(0);
            default: printf("invalid option");
        }
    }while(option<5);
}


