#include <stdio.h>
#include <stdlib.h>

/// ADT for CSLL Node

struct node
{
    int info;
    struct node *link;
};

struct node *create_csll(struct node *start)
{
    struct node *new;
    int item;
    new = (struct node *)malloc(sizeof(struct node));
    if (new == NULL)
    {
        printf("\nOVERFLOW\n");
    }
    else
    {
        printf("Enter item:");
        scanf("%d", &item);
        new->info = item;
        new->link = new;
    }
}
void traversal_CSLL(struct node *start)
{
    struct node *ptr = start;
    printf("Content of CSLL:\n%d", ptr->info);
    ptr = ptr->link;
    while (ptr != start)
    {
        printf(" %d", ptr->info);
        ptr = ptr->link;
    }
}

struct node *insert_beg(struct node *start)
{
    struct node *new, *ptr;
    int item;
    new = (struct node *)malloc(sizeof(struct node));
    if (new == NULL)
    {
        printf("\nOVERFLOW\n");
    }
    else
    {
        printf("Enter item: ");
        scanf("%d", &new->info);
        if (start == NULL)
        {
            start = new;
            new->link = start;
        }
        else
        {
            ptr = start;
            while (ptr->link != start)
            {
                ptr = ptr->link;
            }
            ptr->link = new;
            new->link = start;
            start = new;
        }
    }
    return start;
}

struct node *insert_end(struct node *start)
{
    struct node *new, *ptr;
    int item;
    new = (struct node *)malloc(sizeof(struct node));
    if (new == NULL)
    {
        printf("\nOVERFLOW\n");
    }
    else
    {
        printf("Enter item: ");
        scanf("%d", &new->info);
        if (start == NULL)
        {
            start = new;
            new->link = start;
        }
        else
        {
            ptr = start;
            while (ptr->link != start)
            {
                ptr = ptr->link;
            }
            ptr->link = new;
            new->link = start;
        }
    }
    return start;
}

int main()
{
    struct node *start = NULL;
    start = create_csll(start);
    int option;
    do
    {
        printf("\nMenu:\n1.Traversal.\n2.Insert_BEG.\n3.Insert_END.\n4.Exit.\nEnter your choice: ");
        scanf("%d", &option);
        switch (option)
        {
        case 1:
            traversal_CSLL(start);
            break;
        case 2:
            start = insert_beg(start);
            traversal_CSLL(start);
            break;
        case 3:
            start = insert_end(start);
            traversal_CSLL(start);
            break;
        case 4:
            exit(0);
        default:
            printf("\nInvalid option\n");
        }
    } while(option < 4);
}
