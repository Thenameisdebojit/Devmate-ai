#include <stdio.h>

// Function declarations
void inputArray(int arr[], int size);
void displayArray(int arr[], int size);
int binarySearch(int arr[], int size, int key);

// Main function
int main() {
    int arr[100], n, key, result;

    printf("Enter number of elements in sorted array: ");
    scanf("%d", &n);

    inputArray(arr, n);

    printf("The array is: ");
    displayArray(arr, n);

    printf("\nEnter the element to search: ");
    scanf("%d", &key);

    result = binarySearch(arr, n, key);

    if (result != -1)
        printf("Element found at index %d.\n", result);
    else
        printf("Element not found in the array.\n");

    return 0;
}

// Function to input array elements
void inputArray(int arr[], int size) {
    printf("Enter %d sorted elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
}

// Function to display array elements
void displayArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Function to perform binary search
int binarySearch(int arr[], int size, int key) {
    int low = 0, high = size - 1;

    while (low <= high) {
        int mid = (low + high) / 2;

        if (arr[mid] == key)
            return mid;
        else if (arr[mid] < key)
            low = mid + 1;
        else
            high = mid - 1;
    }

    return -1;
}
