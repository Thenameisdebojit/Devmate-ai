#include<stdio.h>
int main(){
    float price[3]={100.0, 200.0, 300.0};
    // printf("enter the price of 3 items\n");
    // scanf("%f",&price[0]);
    // scanf("%f",&price[1]);
    // scanf("%f",&price[2]);
    printf("price of item 1 is %.2f\n",price[0]+(price[0]*0.18));
    printf("price of item 2 is %.2f\n",price[1]+(price[1]*0.18));
    printf("price of item 3 is %.2f\n",price[2]+(price[2]*0.18));
    // printf("enter marks of phy");
    // scanf("%d",&marks[0]);
    // printf("enter marks for maths");
    // scanf("%d",&marks[1]);
    // printf("enter marks for chem");
    // scanf("%d",&marks[2]);
    // printf("enter marks for comp");
    // scanf("%d",&marks[3]);
    // printf("enter marks for english");
    // scanf("%d",&marks[4]);
    // printf(" marks in phy is%d\n",marks[0]);
    // printf(" marks in maths is%d\n",marks[1]);
    // printf(" marks in chem is%d\n",marks[2]);
    // printf(" marks in comp is%d\n",marks[3]);
    // printf(" marks in english is%d\n",marks[4]);
}