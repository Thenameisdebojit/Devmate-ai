#include<stdio.h>
void displayarray(int arr[], int size)
{
    for(int i=0; i<size; i++)
    {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
void bubblesort(int arr[],int size){
    int issorted=0;
    printf("Sorting the array using Bubble Sort...\n");
    for(int i=0;i<size-1;i++){
        issorted=1;
        printf("working on pass no %d\n", i+1);
        for(int j=0;j<size-i-1;j++){
            if(arr[j]>arr[j+1]){
                int temp=arr[j];
                arr[j]=arr[j+1];
                arr[j+1]=temp;
            }
        }
    }
}
int main(){
    int arr[100], size;
    printf("Enter the number of elements in the array: ");
    scanf("%d", &size);
    printf("Enter the elements of the array:\n");
    for(int i=0; i<size; i++){
        scanf("%d", &arr[i]);
    }
    printf("Original array:\n");
    displayarray(arr, size);
    bubblesort(arr, size);
    printf("Sorted array:\n");
    displayarray(arr, size);
    return 0;
}