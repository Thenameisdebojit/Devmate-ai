#include <stdio.h>

int binarySearch(int arr[], int low, int high, int key)
{
    if (low <= high)
    {
        int mid = (low + high) / 2;

        // If element is found at mid
        if (arr[mid] == key)
            return mid;

        // If element is smaller than mid
        else if (key < arr[mid])
            return binarySearch(arr, low, mid - 1, key);

        // If element is greater than mid
        else
            return binarySearch(arr, mid + 1, high, key);
    }
    return -1;  // Element not found
}

int main()
{
    int arr[] = {10, 20, 30, 40, 50, 60};
    int n = 6, key = 40;

    int result = binarySearch(arr, 0, n - 1, key);

    if (result != -1)
        printf("Element found at index %d", result);
    else
        printf("Element not found");

    return 0;
}
