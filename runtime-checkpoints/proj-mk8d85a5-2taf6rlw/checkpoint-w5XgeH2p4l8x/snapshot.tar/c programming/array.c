#include<stdio.h>
#include<stdlib.h>
void create(int a[10], int *n) //Defining of Create Function
{
    int i;
    printf("\nEnter n:\n");
    scanf("%d", n);
    printf("\nEnter Data into array:\n");
    for(i = 0; i < *n; i++)
        scanf("%d", &a[i]);
}
void traverse(int a[10], int lb , int ub)
{
    int i=lb;
    printf("\nContent of the Array: \n");
    while(i <= ub)
    {
        printf("%d\t", a[i]);
        i++;
    }
}
void insert(int a[10], int  *n, int pos, int item)
{
    int i= *n-1;
    while(i >= pos-1)
    {
        a[i+1] = a[i];
        i--;
    }
    a[pos-1] = item;
 (*n)++;
    printf("\nAfter Insertion :\n");
    traverse(a, 0, *n-1);
}
void deletion(int a[10], int *n, int pos)
{
    int i, item= a[pos-1];
    for(i = pos-1; i < *n; i++)
    {
        a[i] = a[i+1];
    }
    (*n)--;
    printf("\nDeleted Item: %d\n", item);
    printf("\nAfter Deletion :\n");
    traverse(a, 0, *n-1);
}
void LSearch(int a[10], int n, int item)
{
    int i;
    for(i = 0; i < n; i++)
    {
        if(a[i] == item)
        {
            printf("\nSuccesful Search.\nElement %d found at position %d\n", item, i+1);
            break;
        }
    }
    if(i == n)
    {
        printf("\nUnsuccesful Search.\n");
    }
}
void bubbleSort(int a[10], int n) {
    int i, j, temp;
    printf("\nArray before Bubble Sort:\n");
    traverse(a, 0, n - 1);
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < (n - i) - 1; j++) 
        {
            if (a[j] < a[j + 1]) //For Descending order
            // if (a[j] > a[j + 1]) //For Ascending order
            {
                // Swap a[j] and a[j + 1]
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
printf("\nArray after Bubble Sort:\n");
    traverse(a, 0, n - 1);
}

int main()
{
    int a[10], n, option , item , pos;
    create(a, &n); //Call to Create Function
    do{
    printf("\nMenu:\n1. Traverse\n2. Insertion\n3. Deletion\n4. Linear Search\n5. Bubble Sort\n6. Exit\nEnter your choice:\n");
    scanf("%d", &option);
    switch(option)
    {
        case 1:
            traverse(a, 0, n-1); //Call to Traverse Function
            break;
        case 2:
            printf("\nEnter item and position for insertion:\n");
            scanf("%d %d", &item, &pos);
            insert(a, &n, pos, item); //Call to Insertion Function
            break;
        case 3:
            printf("\nEnter position for deletion:\n");
            scanf("%d", &pos);
            deletion(a, &n, pos); //Call to Deletion Function
            break;
        case 4:
            printf("\nEnter item for linear search:\n");
            scanf("%d", &item);
            LSearch(a, n, item); //Call to Linear Search Function
            break;
        case 5:
            bubbleSort(a, n); //Call to Bubble Sort Function
            break;
        case 6:
            exit(0);
        default:
            printf("Invalid Option!\n");
    } 
    } while(option<7);
    return 0;
}