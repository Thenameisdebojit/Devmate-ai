#include<stdio.h>
#include<stdlib.h>
struct queue{
    int front,rear;
    int *arr;
    int size;
    int val;
};
int isEmpty(struct queue *q){
    return (q->front == q->rear);
}
int isFull(struct queue*q){
    return ((q->rear + 1) % q->size == q->front);
}
int dequeue(struct queue *q){
    if(isEmpty(q)){
        printf("Queue is empty\n");
        return -1;
    }
    else{
        int val = q->arr[q->front];
        q->front = (q->front + 1) % q->size;
        return val;
    }
}
int enqueue(struct queue*q,int val){
    if(isFull(q)){
        printf("Queue is full\n");
        return -1;
    }
    else{
        q->rear=(q->rear+1)%q->size;
        q->arr[q->rear]=val;
        return val;
    }
    
}
void traverse(struct queue *q){
    printf("queue elements :");
    if(isEmpty(q)){
        printf("queue is empty");
    }
    else{
        printf("queue elements are: ");
        for(int i=0;i<q->size;i++){
            printf("%d",q->arr[(q->front + i) % q->size]);
            printf("\t ");
        }
    }
    printf("\n");
}
int main(){
    struct queue *q=(struct queue*)malloc(sizeof(struct queue));
    q->front = 0;
    q->rear = 0;
    q->size = 8;
    q->arr = (int*)malloc(q->size * sizeof(int));
    int option;
    printf("\nMenue\n1.Enqueue\n2.Dequeue\n3.Traverse\n4.Exit\n:");
    do{
        printf("enter your option:");
        scanf("%d",&option);
        switch(option){
            case 1:{
                int value;
                printf("enter value to enqueue:");
                scanf("%d",&value);
                enqueue(q,value);
            }
            case 2:{
                int val = dequeue(q);
                if(val != -1){
                    printf("Dequeued element: %d\n", val);
                }
            }
            case 3:{
                traverse(q);
            }
        }
    }while(option != 4);
    // enqueue(q, 10);
    // enqueue(q, 20);
    // enqueue(q, 30);
    // enqueue(q, 40);
    // enqueue(q, 50);
    // enqueue(q, 60);
    // enqueue(q, 70);
    // enqueue(q, 80);
    // printf("Dequeued element: %d\n", dequeue(q));
    // printf("Dequeued element: %d\n", dequeue(q));
    // traverse(q);
    return 0;
}