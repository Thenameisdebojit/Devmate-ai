#include<stdio.h>
#include<stdlib.h>
struct stack{
    int size;
    int top;
    int *arr;
};
int isempty(struct stack* ptr){
    if(ptr->top== -1){
        return 1;
    }
    else{
        return 0;
    }
}
int isfull(struct stack* ptr){
    if(ptr->top==ptr->size-1){
        return 1;
    }  
    else{
        return 0;
    }
}
void traverse(struct stack* ptr){
    for(int i=0;i<=ptr->top;i++){
        printf("%d\n",ptr->arr[i]);
    }
}
int main(){
    struct stack *s;
    s->size=80;
    s->top=-1;
    s->arr=(int*)malloc(s->size*sizeof(int));

    //pushing element manually
    s->top++;
    s->arr[s->top]=45;
     s->top++;
    s->arr[s->top]=55;
     s->top++;
    s->arr[s->top]=65;
     s->top++;
    s->arr[s->top]=75;
     s->top++;
    s->arr[s->top]=85;
     s->top++;
    s->arr[s->top]=95;
     s->top++;
    s->arr[s->top]=105;

    //check if stack is empty
    // if(isempty(s)){
    //     printf("stack is empty");
    // }
    // else{
    //     printf("stack is not empty");
    // }

    // return 0;
    //check if stack is full
    if(isfull(s)){
        printf("stack is full");
    }
    else{
        printf("stack is not full");
    }
    traverse(s);
    return 0;
}