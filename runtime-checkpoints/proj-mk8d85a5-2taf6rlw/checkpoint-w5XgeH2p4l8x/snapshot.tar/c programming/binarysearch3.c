#include<stdio.h>
#include<stdlib.h>

void create(int a[10], int *n) {
    int i;
    printf("Enter number of elements (max 10): ");
    scanf("%d", n);
    if (*n > 10 || *n < 0) {
        printf("Invalid number of elements.\n");
        *n = 0;
        return;
    }
    for(i = 0; i < *n; i++) {
        printf("Enter element: ");
        scanf("%d", &a[i]);
    }
}

void Traverse(int a[10], int lb, int ub) {
    int i;
    for(i = lb; i < ub; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void LSearchNonRecursive(int a[10], int *n, int item) {
    int i;
    for(i = 0; i < *n; i++) {
        if(a[i] == item) {
            printf("Item found at position %d\n", i);
            break;
        }
    }
    if(i == *n)
        printf("Item not found\n");
}

int LSearchRecursive(int a[10], int *n, int item, int index){
    if(index >= *n) {
        return -1;
    }
    if(a[index] == item) {
        return index ;
    }
    else {
        return LSearchRecursive(a, n, item, index + 1);
    }
}

void Sort(int a[10], int *n) {
    int i, j, temp;
    for(i = 0; i < *n - 1; i++) {
        for(j = 0; j < *n - i - 1; j++) {
            if(a[j] > a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
    Traverse(a, 0, *n);
}

int BinarySearchNonRecursive(int a[10], int n, int item) {
    int low = 0, high = n - 1, mid;
    while(low <= high) {
        mid = (low + high) / 2;
        if(a[mid] == item)
            return mid;
        else if(a[mid] < item)
            low = mid + 1;
        else
            high = mid - 1;
    }
    return -1;
}

int BinarySearchRecursive(int a[10], int low, int high, int item) {
    if (low > high)
        return -1;
    int mid = (low + high) / 2;
    if (a[mid] == item)
        return mid;
    else if (a[mid] > item)
        return BinarySearchRecursive(a, low, mid - 1, item);
    else
        return BinarySearchRecursive(a, mid + 1, high, item);
}

int main() {
    int a[10], n = 0, item, pos, choice;
    create(a, &n);
    do {
        printf("\n1. Traverse\n2. Linear Search (Non-Recursive)\n3. Linear Search (Recursive)\n4. Sort\n5. Traverse\n");
        printf("6. Binary Search (Non-Recursive)\n7. Binary Search (Recursive)\n8. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch(choice) {
            case 1:
                Traverse(a, 0, n);
                break;
            case 2:
                printf("Enter item to search: ");
                scanf("%d", &item);
                LSearchNonRecursive(a, &n, item);
                break;
            case 3:
                printf("Enter item to search: ");
                scanf("%d", &item);
                pos = LSearchRecursive(a, &n, item, 0);
                if(pos == -1)
                    printf("Item not found\n");
                else
                    printf("Item found at position %d\n", pos);
                break;
            case 4:
                Sort(a, &n);
                break;
            case 5:
                Traverse(a, 0, n);
                break;
            case 6:
                printf("Enter item to search (array must be sorted): ");
                scanf("%d", &item);
                pos = BinarySearchNonRecursive(a, n, item);
                if(pos == -1)
                    printf("Item not found\n");
                else
                    printf("Item found at position %d\n", pos);
                break;
            case 7:
                printf("Enter item to search (array must be sorted): ");
                scanf("%d", &item);
                pos = BinarySearchRecursive(a, 0, n - 1, item);
                if(pos == -1)
                    printf("Item not found\n");
                else
                    printf("Item found at position %d\n", pos);
                break;
            case 8:
                exit(0);
            default:
                printf("Invalid choice! Please try again.\n");
        }
    } while(choice != 8);

    return 0;
}
