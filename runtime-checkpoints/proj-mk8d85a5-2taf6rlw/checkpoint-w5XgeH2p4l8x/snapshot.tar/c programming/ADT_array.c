#include<stdio.h>
#include<stdlib.h>
struct MyArray{
    int total_size;
    int used_size;
    int *ptr;
};
void createArray(struct MyArray*arr ,int total_size ,int used_size){
    arr->total_size = total_size;
    arr->used_size = used_size;
    arr->ptr = (int*)malloc(total_size * sizeof(int));
}
void storeArray(struct MyArray*arr){
    int n;
    for(int i=0;i<arr->used_size;i++){
        printf("enter elements of array");
        scanf("%d", &n);
        arr->ptr[i] = n;
    }
}
void showArray(struct MyArray*arr){
    for(int i = 0; i < arr->used_size; i++){
        printf("%d ", arr->ptr[i]);
        
    }
    printf("\n");
}
int main(){
    struct MyArray arr;
    createArray(&arr, 100, 10);
    printf("we are storing elements in the array\n");
    storeArray(&arr);
    printf("we are displaying elements of the array\n");
    showArray(&arr);
    return 0;
}
