//pointer arithmetic example
#include<stdio.h>
int main(){
    // int price=60;
    // int*ptr=&price;
    //  printf("ptr = %u\n", ptr);
    // ptr++;
    // printf("ptr = %u\n", ptr);
    int age=78;
    int _age=90;
    int*ptr=&age;
    int*ptr1=&_age;
    printf("difference = %u\n", ptr1-ptr);
    printf("comparision = %u\n", ptr1==ptr);
}