#include<stdio.h>
void display(int arr[],int n){
    for(int i=0;i<n;i++){
        printf("%d ",arr[i]);
    }
    printf("\n");
}
int Linearsearch(int arr[100],int n,int element){
    for(int i=0;i<n;i++){
        if(arr[i]==element){
            return i; // Return the index of the found element
        }
    }
    return -1; // Return -1 if the element is not found
}
int main(){
    int arr[100],n,element;
    printf("enter the no of elements of array:");
    scanf("%d",&n);
    printf("enter the elements of the array:");
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("the elements of the array are:");
    display(arr,n);
    printf("enter the elements to be searched");
    scanf("%d",&element);
    int result=Linearsearch(arr,n,element);
    if(result!=-1){
        printf("element found at index %d",result);
    }
    else{
        printf("element not found");
    }
}