#include<stdio.h>
#include<stdlib.h>
struct queue{
    int front,rear;
    int *arr;
    int size;
};
int isEmpty(struct queue *q){
    return q->front == q->rear;
}
int isFull(struct queue *q){
    return q->rear == q->size-1;
}
void enqueue(struct queue *q,int value){
    if(isFull(q)){
        printf("queue is full");
    }
    else{
        q->arr[q->rear]=value;
        q->rear++;
    }
}
void dequeue(struct queue *q){
    if (isEmpty(q))
    {
        printf("Queue is empty");
    }
    else{
        int value = q->arr[q->front];
        q->front++;
        printf("Dequeued: %d\n", value);
    }
}
void traversal(struct queue *q){
    if (isEmpty(q))
    {
        printf("Queue is empty");
    }
    else{
        printf("Queue elements are: ");
        for (int i = q->front; i < q->rear; i++)
        {
            printf("%d ", q->arr[i]);
        }
        printf("\n");
    }
}
int main(){
    struct queue*q=(struct queue*)malloc(sizeof(struct queue));
    q->front=-1;
    q->rear=-1;
    int size = 100;
    q->arr=(int*)malloc(100*sizeof(int));
            // Assuming a fixed size for simplicity
    q->size = size;
    enqueue(q, 10);
    enqueue(q, 20);
    enqueue(q, 30);
    dequeue(q);
    traversal(q);
    return 0;
}
