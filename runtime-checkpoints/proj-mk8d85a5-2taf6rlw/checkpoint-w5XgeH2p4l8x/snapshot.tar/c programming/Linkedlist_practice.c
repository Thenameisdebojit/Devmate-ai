#include<stdio.h>
#include<stdlib.h>
// Define Node Structure for Singly Linked List
struct node{
    int info;
    struct node *link;
};
typedef struct node NODE;
// Function to create the first node
NODE*create(NODE*start){
    NODE*newnode;
    int item;
    newnode=(NODE*)malloc(sizeof(NODE));
    if(newnode==NULL){
        printf("\n OVERFLOW\n");
    }
    else{
        printf("enter item for 1st node \n");
        scanf("%d",&item);
        newnode->info=item;
        newnode->link=NULL;
    }
    return newnode;
}

void traverse(NODE*start){
    if(start==NULL){
        printf("\n list is empty\n");
    }
    else{
        NODE*ptr=start;
        printf("\ncontents are:\n");
        while(ptr!=NULL){
            printf("%d\t",ptr->info);
            ptr=ptr->link;
        }
    }
}
NODE* insert_beg(NODE*start,int item){
    printf("in insert beg\n");
    scanf("%d",&item);
    NODE*new;
    new=(NODE*)malloc(sizeof(NODE));
    if(new==NULL){
        printf("\n OVERFLOW\n");
    }
    else{
        new->info=item;
        new->link=start;
        start=new;
    }
    return start;
}
NODE*insert_index(NODE*start,int item,int index){
    printf("in insert index\n");
    scanf("%d",&item);
    scanf("%d",&index);
    NODE*new,*ptr,*prev;
    new=(NODE*)malloc(sizeof(NODE));
    int i=0;
    while(i!=index-1){
        ptr->link=prev->link;
        prev->link=new;
        new->info=item;


    }

    
        
}
    return start;
}


int main(){
    NODE*start=NULL;
    start=create(start);
    //printf("element:%d",start->info);
    traverse(start);
 
}
