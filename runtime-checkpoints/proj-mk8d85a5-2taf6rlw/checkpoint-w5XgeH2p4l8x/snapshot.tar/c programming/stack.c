
#include <stdio.h>
#include <stdlib.h> 
#define MAXSIZE 5

// ADT for Stack
struct stack {
    int a[MAXSIZE];

    int top;
};

typedef struct stack STACK;

// Check if stack is full
int isfull(STACK *s) {
    return (s->top == MAXSIZE - 1);
}

// Check if stack is empty
int isempty(STACK *s) {
    return (s->top == -1);
}

// Push operation
void push(STACK *s, int item) {
    if (isfull(s))
        printf("\nOVERFLOW\n");
    else {
        s->top++;
        s->a[s->top] = item;
    }
}

// Pop operation
void pop(STACK *s) {
    int item;
    if (isempty(s))
        printf("\nUNDERFLOW\n");
    else {
        item = s->a[s->top];
        s->top--;
        printf("\nItem Deleted = %d\n", item);
    }
}

// Peep (display) operation
void peep(STACK *s) {
    int i;
    if (isempty(s))
        printf("\nEMPTY STACK.\n");
    else {
        printf("\nContent of the stack: \n");
        for (i = s->top; i >= 0; i--)
            printf("%d\n", s->a[i]);
    }
}

// Main function
int main() {
    STACK s;
    s.top = -1;  // Initialize the stack
    int option, item;

    do {
        printf("\nMENU:\n1. Push\n2. Pop\n3. Peep\n4. Exit\n");
        printf("Enter Your Choice: ");
        scanf("%d", &option);

        switch (option) {
            case 1:
                printf("Enter Item: ");
                scanf("%d", &item);
                push(&s, item);
                printf("\nAfter push:\n");  
                break;
            case 2:
                pop(&s);
                printf("\nAfter pop:\n");
                break;
            case 3:
                peep(&s);
                break;
            case 4:
                exit(0);
            default:
                printf("\nInvalid Option.\n");
        }
    } while (option != 4);

    return 0;
}