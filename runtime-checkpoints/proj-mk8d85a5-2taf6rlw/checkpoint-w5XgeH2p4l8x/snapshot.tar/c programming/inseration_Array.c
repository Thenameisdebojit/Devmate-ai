#include<stdio.h>
void display(int arr[100],int n){
    for(int i=0;i<n;i++){
        printf("%d ", arr[i]);
    }
    printf("\n");
}
void insert(int arr[100],int n ,int element,int pos){
    if(pos<0 || pos>n){
        printf("invalid position");
        return;
    }
    for(int i=n;i>pos;i--){
        arr[i] = arr[i-1];
    }
    arr[pos] = element;

    return ;
}

int main(){
    int arr[100]={12,23,45,67,89,90,99,100};
    printf("the array before insertion is\n");
    display(arr,8);
    int element, pos;
    printf("Enter the element to be inserted: ");
    scanf("%d", &element);
    printf("Enter the position of element to be inserted: ");
    scanf("%d", &pos);
    printf("the array after insertion is\n");
    insert(arr, 8, element, pos);
    display(arr, 9);

}


// int main(){
//     int arr[100]={1,2,3,4,5};
//     printf("the array before insertion is\n");
//     for(int i=0;i<5;i++){
//         printf("%d ", arr[i]);
//     }
//     printf("\n");
//     int n,pos,i;
//     printf("enter the element to be inserted");
//     scanf("%d", &n);
//     printf("enter the position of element to be inserted");
//     scanf("%d", &pos);
//     for(i=5;i>=pos;i--){
//         arr[i] = arr[i-1];
//     }
//     arr[pos] = n;
//     printf("the array after insertion is\n");
//     for(i=0;i<6;i++){
//         printf("%d ", arr[i]);
//     }

// }