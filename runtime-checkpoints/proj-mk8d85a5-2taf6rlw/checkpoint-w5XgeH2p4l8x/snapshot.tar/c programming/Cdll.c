#include <stdio.h>
#include <stdlib.h>

// Define Node Structure for Circular Doubly Linked List
struct node {
    int info;
    struct node *prev;
    struct node *next;
};

// Function to create the first node
struct node* create(struct node* start) {
    struct node* newnode;
    int item;
    newnode = (struct node*)malloc(sizeof(struct node));
    if (newnode == NULL) {
        printf("\nOVERFLOW\n");
    } else {
        printf("\nEnter Item for 1st Node:\n");
        scanf("%d", &item);
        newnode->info = item;
        newnode->next = newnode;
        newnode->prev = newnode;
        start = newnode;
    }
    return start;
}

// Function to traverse the list
void traverse(struct node* start) {
    if (start == NULL) {
        printf("\nList is Empty\n");
        return;
    }

    struct node* ptr = start;
    printf("\nCDLL Contains:\n");
    do {
        printf("%d\t", ptr->info);
        ptr = ptr->next;
    } while (ptr != start);
    printf("\n");
}

// Insert at beginning
struct node* insert_beg(struct node* start) {
    struct node* newnode;
    int item;
    newnode = (struct node*)malloc(sizeof(struct node));
    if (newnode == NULL) {
        printf("\nOVERFLOW\n");
        return start;
    }

    printf("\nEnter Item:\n");
    scanf("%d", &item);
    newnode->info = item;

    if (start == NULL) {
        newnode->next = newnode;
        newnode->prev = newnode;
        start = newnode;
    } else {
        struct node* last = start->prev;
        newnode->next = start;
        newnode->prev = last;
        start->prev = newnode;
        last->next = newnode;
        start = newnode;
    }

    traverse(start);
    return start;
}

// Insert at end
struct node* insert_end(struct node* start) {
    struct node* newnode;
    int item;
    newnode = (struct node*)malloc(sizeof(struct node));
    if (newnode == NULL) {
        printf("\nOVERFLOW\n");
        return start;
    }

    printf("\nEnter Item:\n");
    scanf("%d", &item);
    newnode->info = item;

    if (start == NULL) {
        newnode->next = newnode;
        newnode->prev = newnode;
        start = newnode;
    } else {
        struct node* last = start->prev;
        newnode->next = start;
        newnode->prev = last;
        last->next = newnode;
        start->prev = newnode;
    }

    traverse(start);
    return start;
}

// Delete from beginning
struct node* delete_beg(struct node* start) {
    if (start == NULL) {
        printf("\nUNDERFLOW\n");
        return start;
    }

    struct node* temp = start;

    if (start->next == start) {
        printf("\nItem Deleted: %d\n", temp->info);
        free(temp);
        start = NULL;
    } else {
        struct node* last = start->prev;
        start = start->next;
        start->prev = last;
        last->next = start;
        printf("\nItem Deleted: %d\n", temp->info);
        free(temp);
    }

    traverse(start);
    return start;
}

// Delete from end
struct node* delete_end(struct node* start) {
    if (start == NULL) {
        printf("\nUNDERFLOW\n");
        return start;
    }

    struct node* last = start->prev;

    if (last == start) {
        printf("\nItem Deleted: %d\n", last->info);
        free(last);
        start = NULL;
    } else {
        struct node* second_last = last->prev;
        second_last->next = start;
        start->prev = second_last;
        printf("\nItem Deleted: %d\n", last->info);
        free(last);
    }

    traverse(start);
    return start;
}

// Main function
int main() {  
    struct node* start = NULL;
    int op;
    start = create(start);

    do {
        printf("\nMENU:\n1.Traversal\n2.Insert_Beg\n3.Insert_End\n4.Delete_Beg\n5.Delete_End\n6.Exit\n");
        printf("\nEnter Your Choice:\n");
        scanf("%d", &op);
        switch (op) {
            case 1: traverse(start); break;
            case 2: start = insert_beg(start); break;
            case 3: start = insert_end(start); break;
            case 4: start = delete_beg(start); break;
            case 5: start = delete_end(start); break;
            case 6: exit(0);
            default: printf("\nInvalid Choice!\n");
        }
    } while (op < 7);

    return 0;
}
