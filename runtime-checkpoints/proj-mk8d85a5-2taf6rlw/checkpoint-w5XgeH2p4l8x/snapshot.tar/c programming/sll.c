#include<stdio.h>
#include<stdlib.h>
struct node{
    int info;
    struct node* link;
};
typedef struct node Node;
struct node* create_sll(Node * start){
    Node* new;
    new=(Node*)malloc(sizeof(Node));
    if(new==NULL){
        printf("OVERFLOW\n");
    }
    else{
        printf("enter item:\n");
        scanf("%d",&new->info);
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
        
    }
    return start;
}
struct node* traversal(Node* start){
    Node* ptr=start;
    if(start==NULL){
        printf("list is empty\n");
    }
    else{
       while(ptr!=NULL){
        printf("%d\t ",ptr->info);
        ptr=ptr->link;
       }
       printf("\n");
    }
}
struct node* insertAtBeg(Node* start){
    Node*new;
    new=(Node*)malloc(sizeof(Node));
    if(new==NULL){
        printf("OVERFLOW\n");
    }
    else{
        printf("enter item:\n");
        scanf("%d",&new->info);
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
        else{
            new->link=start;
            start=new;
        }
    }
    return start;
}
struct node* insertAtEnd(Node*start){
    Node*new,*ptr=start;
    new=(Node*)malloc(sizeof(Node));
    if(new==NULL){
        printf("OVERFLOW\n");
    }
    else{
        printf("enter item:\n");
        scanf("%d",&new->info);
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
        else{
            while(ptr->link!=NULL){
                ptr=ptr->link;
            }
            ptr->link=new;
            new->link=NULL;
        }
    }
    return start;
}
struct node* insertAtIndex(Node*start){
    Node*new,*ptr=start;
    int index,i=1;
    new=(Node*)malloc(sizeof(Node));
    if(new==NULL){
        printf("OVERFLOW\n");
    }
    else{
        printf("enter item:\n");
        scanf("%d",&new->info);
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
        else{
            printf("enter index:\n");
            scanf("%d",&index);
            while(i<index-1 && ptr!=NULL){
                ptr=ptr->link;
                i++;
            }
            if(ptr==NULL){
                printf("there are less than %d elements\n",index);
            }
            else{
                new->link=ptr->link;
                ptr->link=new;
            }
        }
    }
    return start;
}

struct node* deleteAtBeg(Node* start){
    Node* ptr=start;
    if(start==NULL){
        printf("OVERFLOW\n");
    }
    else{
        start=ptr->link;
        printf("item deleted:%d\n",ptr->info);
        free(ptr);
    }
    return start;
}
struct node* deleteAtEnd(Node* start){
    Node* ptr=start,*prev=start;
    if(start==NULL){
        printf("OVERFLOW\n");
    }
    else{
        while(ptr->link!=NULL){
            prev=ptr;
            ptr=ptr->link;
        }
        prev->link=NULL;
        printf("item deleted:%d\n",ptr->info);
        free(ptr);
    }
    return start;
}
struct node* deleteAtIndex(Node* start){
    Node* ptr=start,*prev=start;
    int index,i=1;
    if(start==NULL){
        printf("OVERFLOW\n");

    }
    else{
        printf("enter index:");
        scanf("%d",&index);
        while(i<index-1 && ptr!= NULL){
            prev=ptr;
            ptr=ptr->link;
            i++;
        }
        if(ptr==NULL){
            printf("there are less than %d elements\n",index);
        }
        else{
            prev->link=ptr->link;
            printf("item deleted:%d\n",ptr->info);
            free(ptr);
        }
    }
    return start;
}
void searching_sll(Node* start ,int item){
    Node* ptr=start;
    int loc=1;
    while(ptr!=NULL && ptr->info!=item){
        ptr=ptr->link;
        loc++;
    }
    if(ptr==NULL){
        printf("item not found\n");
    }
    else{
        printf("item found at location:%d\n",loc,item);
    }
}
void sorting_sll(Node* start){
    Node* ptr=start,*ptr2;
    int temp;
    while(ptr->link!=NULL){
        ptr2=ptr->link;
        while(ptr2->link!=NULL){
            if(ptr->info>ptr2->info){
                temp=ptr->info;
                ptr->info=ptr2->info;
                ptr2->info=temp;
            }
            ptr2=ptr2->link;
        }
        ptr=ptr->link;

    }
}
struct node* reversal(Node* start){
    Node* ptr=start,*prev=NULL,*temp;
    while(ptr!=NULL){
        temp=ptr->link;
        ptr->link=prev;
        prev=ptr;
        ptr=temp;
    }
    start=prev;
    return start;
}
int main(){
    Node* start=NULL;
    int item,option;
    start=create_sll(start);
    do{
        printf("\nMENU\n1->insert at beg\n2->insert at end\n3->insert at end\n4->delete at beg\n5->delete at end\n6->delete at index\n7->sorting\n8->reversal\n9->tarversal\n10->EXIT\nenter your option\n");
        scanf("%d",&option);
        switch(option){
            case 1: start=insertAtBeg(start);
                    traversal(start);
                    break;
            case 2: start=insertAtEnd(start);
                    traversal(start);
                    break;
            case 3: start=insertAtIndex(start);
                    traversal(start);
                    break;
            case 4: start=deleteAtBeg(start);
                    traversal(start);
                    break;
            case 5: start=deleteAtEnd(start);
                    traversal(start);
                    break;
            case 6: start=deleteAtIndex(start);
                    traversal(start);
                    break;
            case 7: printf("enter item to be searched");
                    scanf("%d",&item);
                    searching_sll(start,item);
                    break;

            case 8: printf("before soring");
                    traversal(start);
                    printf("after sorting");
                    sorting_sll(start);
                    traversal(start);
                    break;
            case 9: printf("before reversal");
                    traversal(start);
                    printf("After reversal");
                    start=reversal(start);
                    traversal(start);
                    break;
            case 10: traversal(start);
                    break;
            case 11: printf("Exiting...\n");
                    break;
            default: printf("Invalid option\n");
                    break;
        }
    } while(option != 10);
    return 0;
}
