# My Project

A new project created in Devmate.

## Getting Started

Run the project:
```bash
npm start
```
