//linked stack program
#include<stdio.h>
#include<stdlib.h>
//ADT for linked stack
struct node{
    int info;
    struct node *link;
}; 
struct node *push(struct node*top){
    struct node *new;
    int item;
    new=(struct node*)malloc(sizeof(struct node));
    if(new==NULL){
        printf("stack overflow\n");
    }
    else{
        printf("\n enter item to be pushed\n");
        scanf("%d",&item);
        new->info=item;
        new->link=NULL;
        if(top==new){
            top=new;
        }
        else{
            new->link=top;
            top=new;
        }
    }
    return top;
}
struct node*pop(struct node*top){
    struct node*ptr=top;
    if(top==NULL){
        printf("\n UNDERFLOW\n");
    }
    else{
        printf("\n Item deleted:%d\n",ptr->info);
        top=ptr->link;
        free(ptr);
    }
    return top;
}
void peep(struct node*top){
    struct node*ptr;
    if(top==NULL){
        printf("\n stack is empty\n");
    }
    else{
        printf("\n content of the linked stack\n");
        while(ptr!=NULL){
            printf("%d\t",ptr->info);
            ptr=ptr->link;
        }
    }
}
int main(){
    struct node*top=NULL;
    int op;
    do{
        printf("\n MENU\n1->PUSH\n2->POP\n3->PEEP\n4->EXIT\n enter your option\n");
        scanf("%d",&op);
        switch(op){
            case 1:top=push(top);
                   printf("\n after push");
                   peep(top);
                   break;
                    
            case 2:top=pop(top);
                   printf("\n after pop");
                   peep(top);
                   break;
            case 3:peep(top);
                   break;
            case 4:exit(0);
            default:printf("\n invalid option\n");       
        }
    }while(op<5);
    return 0;
}