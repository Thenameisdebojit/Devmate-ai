#include <stdio.h> 
#include <stdlib.h> 
/// ADT for DLL. Self-Referential Structure. 
struct node 
{ 
    int info; 
    struct node *prev, *next; 
}; 
 
struct node *create_dll(struct node *start) 
{ 
    struct node *new; 
    int item; 
    new = (struct node *)malloc(sizeof(struct node)); 
    if (new == NULL) 
    { 
        printf("\nOVERFLOW\n"); 
    } 
    else 
    { 
        printf("Enter item: "); 
        scanf("%d", &item); 
        new->info = item; 
        new->prev = NULL; 
        new->next = NULL; 
        if (start == NULL) 
        { 
            start = new; 
        } 
    } 
    return start; 
} 
void ftraversal_DLL(struct node *start) 
{ 
    struct node *ptr = start; 
    printf("Content of DLL:\n"); 
    while (ptr != NULL) 
    { 
        printf("%d ", ptr->info); 
        ptr = ptr->next; 
    } 
} 
 
struct node *insert_beg(struct node *start) 
{ 
    struct node *new; 
    int item; 
    new = (struct node *)malloc(sizeof(struct node)); 
    if (new == NULL) 
    { 
        printf("\nOVERFLOW\n"); 
    } 
    else 
    { 
 printf("Enter item: "); 
        scanf("%d", &new->info); 
        new->info = item; 
        new->prev = NULL; 
        if (start == NULL) 
        { 
            start = new; 
        }                                                                                                                                                                                                
else 
        { 
            new->next = start; 
            start->prev = new; 
            start = new; 
        } 
    } 
    return start; 
} 
 
struct node *insert_end(struct node *start) 
{ 
    struct node *new, *ptr; 
    int item; 
    printf("\nEnter item:\n"); 
    scanf("%d", &item); 
    new = (struct node *)malloc(sizeof(struct node)); 
    if (new == NULL) 
        printf("\nOVERFLOW\n"); 
    else 
    { 
        new->info = item; 
        new->prev = NULL; 
        new->next = NULL; 
        if (start == NULL) 
            start = new; 
else 
        { 
            ptr = start; 
            while (ptr->next != NULL) 
                ptr = ptr->next; 
            ptr->next = new; 
            new->prev = ptr; 
  } 
    } 
    traverse(start); 
    return (start); 
} 
 
struct node *insert_loc(struct node *start) 
{ 
    struct node *new, *ptr, *ptr1; 
    int item, i = 1, loc; 
    printf("\nEnter item and loc:\n"); 
    scanf("%d%d", &item, &loc); 
    new = (struct node *)malloc(sizeof(struct node)); 
    if (new == NULL) 
        printf("\nOVERFLOW\n"); 
    else 
    { 
        new->info = item; 
        new->prev = NULL; 
        new->next = NULL; 
        if (start == NULL) 
            start = new; 
else 
        { 
            ptr1 = start; 
            while (i < loc && ptr1 != NULL) 
            { 
                ptr = ptr1; 
                ptr1 = ptr1->next; 
                i++; 
            } 
            if (ptr1 == NULL) 
                printf("\nLoc not found\n");                                                                                                                                                                                                                
else if (ptr1 == start) 
            { 
                new->next = ptr; 
                ptr->prev = new; 
                start = new; 
            } 
            else 
            { 
                ptr->next = new; 
                new->prev = ptr; 
                new->next = ptr1; 
                ptr1->prev = new; 
            } 
        } 
    } 
    traverse(start); 
    return (start); 
} 
 
struct node *delete_beg(struct node *start) { 
    struct node *ptr; 
    if (start == NULL) 
        printf("\nUNDERFLOW\n"); 
    else { 
        ptr = start; 
        start = start->next; 
        start->prev = NULL; 
        traverse(start); 
        free(ptr); 
    } 
    return (start); 
} 
  
struct node *delete_end(struct node *start) 
{ 
    struct node *ptr, *ptr1; 
    if (start == NULL) 
        printf("\nUNDERFLOW\n"); 
    else 
    { 
        ptr1 = start; 
        while (ptr1->next != NULL) 
        { 
            ptr = ptr1; 
            ptr1 = ptr1->next; 
        } 
        if (ptr1 == start) 
            start = NULL; 
        else 
            ptr->next = NULL; 
        traverse(start); 
        free(ptr); 
    } 
    return (start); 
} 
 
struct node *delete_loc(struct node *start) 
{ 
    struct node *ptr, *ptr1; 
    int i = 1, loc; 
    printf("\nEnter the loc of deletion:\n"); 
    scanf("%d", &loc); 
    if (start == NULL) 
        printf("\nUNDERFLOW\n"); 
    else 
    { 
        ptr1 = start; 
        while (i < loc && ptr1 != NULL) 
        { 
            ptr = ptr1; 
            ptr1 = ptr1->next; 
            i++; 
        } 
        if (ptr1 == NULL) 
            printf("\nLOC NOT FOUND\n"); 
        else if (ptr1 == start) 
        { 
            start = start->next; 
            start->prev = NULL; 
        } 
        else if (ptr->next == NULL) 
            ptr->next = NULL; 
        else 
        { 
            ptr->next = ptr1->next; 
            ptr1->next->prev = ptr; 
        } 
        traverse(start); 
        free(ptr); 
    } 
    return (start); 
} 
