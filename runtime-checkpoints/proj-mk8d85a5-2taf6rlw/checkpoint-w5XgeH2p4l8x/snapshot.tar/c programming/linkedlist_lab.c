#include<stdio.h>
#include<stdlib.h>

struct node{
    int info;
    struct node*link;

};
struct node *create_sll(struct node*start){
    struct node*new;
    int item;
    new=(struct node*)malloc(sizeof(struct node));
    if(new==NULL){
        printf("\noverflow\n");
    }
    else{
        printf("enter item");
        scanf("%d",&item);
        new->info=item;
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
        return start;

    }
}
struct node *insert_sll_beg(struct node*start){
    struct node*new;
    int item;
    new=(struct node*)malloc(sizeof(struct node));
    if(new==NULL){
        printf("\noverflow\n");
    }
    else{
        printf("enter item");
        scanf("%d",&item);
        new->info=item;
        new->link=NULL;
        if(start==NULL){
            start=new;
        }
    else{
        new->link=start;
        start=new;
        }
     return start;

    }
}
struct node* insert_sll_end(struct node* start){
	struct node * ptr,*new;
	int item;
	ptr = (struct node*)malloc(sizeof(struct node));
	if(new==NULL)
	printf("/n Overflow");
	else{
		printf("enter item\n");
		scanf("%d\t",&item);
		new->info=item;
		new->link=NULL;
		if(start==NULL)
		start=new;
		else{
		while(ptr->link!=NULL)
		
		ptr=ptr->link;
		ptr->link=new;
		}
	}
	return start;
}
struct node* insert_sll_loc(struct node* start){
    struct node*new;
    struct node*ptr=start;
    int item,loc;
    new=(struct node*)malloc(sizeof(struct node));
    if(new==NULL){
        printf("\noverflow\n");
    }
    else{
        printf("enter item");
        scanf("%d",&item);
        new->info=item;
        new->link=NULL;
        printf("Enter location to insert: ");
        scanf("%d",&loc);
        if(loc==1){
            new->link=start;
            start=new;
        }
        else{
           while(ptr!=NULL && loc>2){
                ptr=ptr->link;
                loc--;
            }
            if(ptr==NULL){
                printf("Location not found\n");
            }
            else{
                new->link=ptr->link;
                ptr->link=new;
            }
    }   }   
    return start;
}
struct node* delete_sll_beg(struct node* start){
    struct node* ptr=start;
    if(start==NULL){
        printf("List is empty\n");
    }
    else{
        start=start->link;
        free(ptr);
    }
    return start;
}

struct node* delete_sll_end(struct node* start){
    struct node* ptr=start;
    struct node* prev=NULL;
    if(start==NULL){
        printf("List is empty\n");
    }
    else{
        while(ptr->link!=NULL){
            prev=ptr;
            ptr=ptr->link;
        }
        if(prev==NULL){
            start=NULL;
        }
        else{
            prev->link=NULL;
        }
        free(ptr);
    }
    return start;
}
struct node* delete_sll_loc(struct node* start){
    struct node*ptr=start;
    struct node*prev=NULL;
    int loc;
    printf("Enter location to delete: ");
    scanf("%d",&loc);
    if(loc==1){
        start=delete_sll_beg(start);
    }
    else{
        for(int i=1;i<loc;i++){
            prev=ptr;
            ptr=ptr->link;
            if(ptr==NULL){
                printf("Location not found\n");
                return start;
            }
        }
        prev->link=ptr->link;
        free(ptr);
    }
    return start;
}
void traversal(struct node*start){
    struct node*ptr=start;
    while(ptr!=NULL){
        printf("%d->",ptr->info);
        ptr=ptr->link;
    }
    printf("NULL\n");
}
void main(){
	struct node* start=NULL;
	int option;
	start=create_sll(start);
	do{
		printf("\nMENU\n1. Traversal\n2. insert at beginning\n3. insert at end\n4. insert at loc\n5. delete at beginning\n6. delete at end\n7. delete at loc \nEnter your choise\n");
		scanf("%d",&option);
		switch(option){
			case 1: traversal(start);break;
			case 2: start=insert_sll_beg(start);break;
			case 3: start=insert_sll_end(start);break;
            case 4: start=insert_sll_loc(start);break;
            case 5: start=delete_sll_beg(start);break;
            case 6: start=delete_sll_end(start);break;
            case 7: start=delete_sll_loc(start);break;
		}
	}while(option<8 );
}