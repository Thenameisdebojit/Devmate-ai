
#include<stdio.h>
// Recursive function for Fibonacci
int fibonacciRecursive(int n) {
    if (n == 0) return 0;
    if (n == 1) return 1;
   

    return fibonacciRecursive(n-1)+fibonacciRecursive(n-2);
}

// Iterative function for Fibonacci
int fibonacciIterative(int n) {
    int a = 0, b = 1, c, i;
    if (n == 0) return a;
    for (i = 2; i <= n; i++) {
        c = a + b;
        a = b;
        b = c;
    }
    return b;
}

int main() {
    int N;

    // Input
    printf("Enter the value of N: ");
    scanf("%d", &N);

    // Iterative approach
    int iterativeResult = fibonacciIterative(N);
    printf("Fibonacci number at position %d (Iterative) = %d\n", N, iterativeResult);

    // Recursive approach
    int recursiveResult = fibonacciRecursive(N);
    printf("Fibonacci number at position %d (Recursive) = %d\n", N, recursiveResult);

return 0;
}