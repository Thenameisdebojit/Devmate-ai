#include<stdio.h>
#include<stdlib.h>
#define MAX_SIZE 10
typedef struct queue {
    int front, rear;
    int *arr[MAX_SIZE];
} cqueue;
int isempty(cqueue *q){
    if(q->front == q->rear)
        return 1;
    else
        return 0;
}
int isfull(cqueue *q){
    if(q->front == 0 && q->rear == MAX_SIZE - 1)
        return 1;
    else
        return 0;
}
void display(cqueue *q){
    if(isempty(q)){
        printf("queue is empty");
    }
    else{
        printf("cqueue elements are:");
        if(q->front<=q->rear) {
            for(int i=q->front; i<=q->rear; i++) {
                printf("%d\t", q->arr[i]);
            }
        }
        else{
            for(int i=q->front;i<MAX_SIZE;i++){
                printf("%d\t", q->arr[i]);
            }
            for(int i=0;i<=q->rear;i++){
                printf("%d\t", q->arr[i]);
            }
        }
       }
}

void cqinsert(cqueue *q,int val){
    if(isfull(q)){
        printf("queue is full");
    }
    else if(q->rear == -1 && q->front == -1){
        q->front=0;
        q->rear=0;
        q->arr[q->rear]=val;
    }
    else if(q->rear == MAX_SIZE-1){
        q->rear=0;
        q->arr[q->rear]=val;
    }
    else{
        q->rear++;
        q->arr[q->rear]=val;
    }
}
void cqdelete(cqueue *q,int val){
    if(isempty(q)){
        printf("queue is empty");
    }
    else{
        val=q->arr[q->front];
        if(q->front == q->rear){
            q->front =-1;
            q->rear=-1;
        }
        else if(q->front == MAX_SIZE-1){
            q->front=0;
        }
        else{
            q->front++;
            printf("Deleted element is:%d",val);
        }
    }

}
void main(){
    cqueue q;
    int val,option;
    q.front=-1;
    q.rear=-1;
    do{
        printf("\nMenu\n1.Insert\n2.Delete\n3.Display\n4.Exit\n:");
        scanf("%d",&option);
        switch(option){
            case 1: printf("enter value to insert:");
            scanf("%d",&val);
            cqinsert(&q,val);
            break;
            case 2: cqdelete(&q,val);
            break;
            case 3: display(&q);
            break;
            case 4: exit(0);
            default: printf("Invalid option");
        }
    }

    while(option<5);
}