#include<stdio.h>
int CountOdd(int arr[],int n);
int main(){
    int arr[]={1,2,3,4,5,6,7,8,9};
    printf("%d",CountOdd(arr,9));
    int n = 9; // Size of the array

}
int CountOdd(int arr[],int n){
    int count=0;
    for(int i=0;i<n;i++){
        if(arr[i]%2!=0){
            count++;
        }
    }
    return count;
}