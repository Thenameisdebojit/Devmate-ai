#include<stdio.h>
void display(int arr[100],int n){
    for(int i=0;i<n;i++){
        printf("%d",arr[i]);
        printf("\t ");
    }
    printf("\n");
}


void delete(int arr[100],int n,int pos){
    if(pos<0 || pos>=n){
        printf("invalid position");
        return;
    }
    for(int i=pos;i<n-1;i++){
        arr[i] = arr[i+1];
    }   
}
int main(){
    int arr[100],n;
    printf("enter the no of elements of array");
    scanf("%d",&n);
    printf("enter the elements of array");
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("array before deletion\n");
    display(arr,n);
    int pos;
    printf("enter the position of element to be deleted");
    scanf("%d",&pos);
    delete(arr,n,pos);
    printf("array after deletion");
    display(arr,n-1);
}