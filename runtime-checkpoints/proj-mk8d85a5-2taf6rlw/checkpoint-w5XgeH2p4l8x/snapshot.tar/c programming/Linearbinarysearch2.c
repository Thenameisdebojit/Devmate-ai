#include<stdio.h>
void display(int arr[100], int n) {
    for(int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}
int binarysearch(int arr[],int n,int element){
    int mid,low,high;
    low=0;
    high=n-1;
    while(low<=high){
        mid=(low+high)/2;
        if(arr[mid]==element){
            return mid;
        }
        if(arr[mid]<element){
            low=mid+1;
        }
        else{
            high=mid-1;
        }
    }
    return -1;

}
int main(){
    int arr[100], n, element;
    printf("enter the no of elements of array");
    scanf("%d",&n);
    printf("enter the elements of sorted   array");
    for(int i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("the elements of the array are:");
    display(arr,n);
    printf("enter the elements to be searched");
    scanf("%d",&element);
    int result=binarysearch(arr,n,element);
    if(result!=-1){
        printf("element found at index %d",result);
    }
    else{
        printf("element not found");
    }
}