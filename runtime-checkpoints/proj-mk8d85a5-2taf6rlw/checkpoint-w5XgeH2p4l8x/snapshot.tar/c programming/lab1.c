#include<stdio.h> 
#include<stdlib.h> 
 
void create(int a[10], int *n) { 
    int i; 
    printf("Enter number of elements (max 10): "); 
    scanf("%d", n); 
    if (*n > 10 || *n < 0) { 
        printf("Invalid number of elements.\n"); 
        *n = 0; 
        return; 
    } 
    for(i = 0; i < *n; i++) { 
        printf("Enter element: "); 
        scanf("%d", &a[i]); 
    } 
} 
void Traverse(int a[10], int lb, int ub) { 
    int i; 
    for(i = lb; i < ub; i++) { 
        printf("%d ", a[i]); 
    } 
    printf("\n"); 
} 
void LSearchNonRecursive(int a[10], int *n, int item) { 
    int i; 
    for(i = 0; i < *n; i++) { 
        if(a[i] == item) { 
            printf("Item found at position %d\n", i); 
            break; 

        }
    } 
    if(i == *n) 
        printf("Item not found\n"); 
} 
int LSearchRecursive(int a[10], int *n, int item, int index){ 
    if(index >= *n) { 
        return -1; 
    } 
    if(a[index] == item) { 
        return index ; 
    } 
    else { 
        return LSearchRecursive(a, n, item, index + 1); 
    } 
} 
void BinarySearch(int a[10], int *n, int item) { 
    Sort(a,n); 
    int beg = 0, end = *n - 1, mid; 
   while(beg <= end) { 
    mid = (beg + end) / 2; 
    if(a[mid] == item) { 
        printf("Item found at position %d\n", mid); 
        return ; 
    } else if(a[mid] < item) { 
        beg = mid + 1; 
    } 
     else { 
        end = mid - 1; 
    } 
} 
}void BinarySearchRecursive(int a[10], int *n, int item, int beg, int end) { 
    Sort(a,n); 
   
    if(beg > end) { 
        printf("Item not found\n"); 
        return; 
    } 
    int mid = (beg + end) / 2; 
    if(a[mid] == item) { 
        printf("Item found at position %d\n", mid); 
        return; 
    } else if(a[mid] < item) { 
        BinarySearchRecursive(a, n, item, mid + 1, end); 
    } else { 
        BinarySearchRecursive(a, n, item, beg, mid - 1); 
    } 
} 
void Sort(int a[10], int *n) { 
    int i, j, temp; 
    for(i = 0; i < *n - 1; i++) { 
        for(j = 0; j < *n - i - 1; j++) { 
            if(a[j] > a[j + 1]) { 
                temp = a[j]; 
                a[j] = a[j + 1]; 
                a[j + 1] = temp; 
            } 
        } 
    } 
    Traverse(a, 0, *n); 
} 
int main() { 
    int a[10], n = 0, item, pos, choice; 
    create(a, &n);
     
 
do { 
printf("\n1. Traverse\n2. Linear Search Non recursion\n3. Linear Search Recursion \n4. BinarySearch\n5. BinarySearchRecursive\n6. Exit\n"); 
        printf("Enter your choice: "); 
        scanf("%d", &choice); 
        switch(choice) { 
            case 1: 
                Traverse(a, 0, n); 
                break; 
            case 2: 
                 printf("Enter item to search: "); 
                scanf("%d", &item); 
                LSearchNonRecursive(a, &n, item); 
                break; 
            case 3: 
                printf("Enter item to search: "); 
                scanf("%d", &item); 
                LSearchRecursive(a, &n, item, 0); 
                if (LSearchRecursive(a, &n, item, 0) == -1) { 
                    printf("Item not found\n"); 
                } else { 
                    printf("Item found at position %d\n", LSearchRecursive(a, &n, item, 0)+1); 
                }   
                break; 
            case 4: 
                printf("Enter item to search: "); 
                scanf("%d", &item); 
                BinarySearch(a, &n, item+1); 
                break; 
            case 5: 
                printf("Enter item to search: "); 
                scanf("%d", &item); 
                BinarySearchRecursive(a, &n, item+1, 0, n - 1);
                break; 
                default: 
                  printf("Invalid choice! Please try again.\n"); 
               } 
} while(choice < 5); 
return 0; 
}
            