
 
#include <stdio.h> 
#include <stdlib.h> 
// ADT for linked queue 
struct node 
{ 
    int info; 
    struct node *link; 
}; 
struct node *front = NULL, *rear = NULL; 
void enqueue() 
{ 
    int item; 
    struct node *newnode; 
    newnode = (struct node *)malloc(sizeof(struct node)); 
    if (newnode == NULL) 
    { 
        printf("\nOverflow\n"); 
        return; 
    } 
    printf("Enter item: "); 
    scanf("%d", &item); 
    newnode->info = item; 
    newnode->link = NULL; 
    if (front == NULL) 
    { 
        front = rear = newnode; 
    } 
    else { 
        rear->link = newnode; 
        rear = newnode; 
    } 
    printf("Item inserted: %d\n", item); 
    }                                                                                                                                                                                                                   
 
  void dequeue() { 
    struct node *temp; 
    if (front == NULL) { 
        printf("\nUnderflow - Queue is empty\n"); 
        return; 
    } 
    temp = front; 
    printf("Item deleted: %d\n", temp->info); 
    front = front->link; 
    if (front == NULL) 
        rear = NULL; 
        free(temp); 
   } 
   void traverse(){ 
    struct node *ptr = front; 
    if (front == NULL){ 
        printf("\nQueue is empty\n"); 
        return; 
    } 
    printf("\nContent of Linked Queue:\n"); 
    while (ptr != NULL){ 
        printf("%d ", ptr->info); 
        ptr = ptr->link; 
    } 
    printf("\n"); 
} 
int main(){ 
    int choice; 
    do { 
        printf("\nMenu:\n1.Insertion\n2.Deletion\n3.Traversal\n4.Exit\n"); 
        printf("Enter your choice: "); 
        scanf("%d", &choice); 
        switch (choice){ 
        case 1: 
            enqueue(); 
            traverse(); 
            break; 
        case 2: 
            dequeue(); 
            traverse(); 
            break; 
        case 3: 
            traverse(); 
            break; 
        case 4: 
            exit(0); 
        default: 
            printf("Invalid choice\n"); 
        } 
    } while (choice < 5); 
 
    return 0; 
} 
